const fs = require('fs');
const path = require('path');

class DrawingState {
    constructor(roomId) {
        this.history = [];
        this.redoStack = [];
        this.filePath = path.join(__dirname, '..', 'data', `drawing-history-${roomId}.json`);
        this.ensureDataDirectoryExists();
        this.currentOpId = 0;
        this.snapshotInterval = 50; // Take snapshot every 50 operations
        this.snapshots = new Map(); // opId -> {imageData, operations}
    }

    ensureDataDirectoryExists() {
        const dir = path.dirname(this.filePath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
    }

    validateStrokePayload(stroke) {
        if (!stroke) return false;
        if (!Array.isArray(stroke.points) || stroke.points.length === 0) return false;
        if (typeof stroke.tool !== 'string' || !['brush', 'eraser'].includes(stroke.tool)) return false;
        if (typeof stroke.width !== 'number' || stroke.width < 1 || stroke.width > 50) return false;
        if (typeof stroke.color !== 'string' || !stroke.color.match(/^#[0-9A-Fa-f]{6}$/)) return false;
        return true;
    }

    addDrawingAction(action) {
        if (!this.validateStrokePayload(action)) {
            console.warn('Invalid stroke payload rejected:', action);
            return null;
        }

        const opId = ++this.currentOpId;
        const op = {
            ...action,
            opId,
            timestamp: Date.now()
        };

        this.history.push(op);
        this.redoStack = []; // Clear redo stack on new action

        // Take snapshot every N operations
        if (this.history.length % this.snapshotInterval === 0) {
            this.takeSnapshot(opId);
        }

        return opId;
    }

    takeSnapshot(opId) {
        const snapshot = {
            opId,
            operations: [...this.history]
        };
        this.snapshots.set(opId, snapshot);

        // Keep only last few snapshots to save memory
        const maxSnapshots = 5;
        if (this.snapshots.size > maxSnapshots) {
            const oldestKey = Math.min(...this.snapshots.keys());
            this.snapshots.delete(oldestKey);
        }
    }

    getDrawingHistory() {
        return this.history;
    }

    undo() {
        if (this.history.length > 0) {
            const lastAction = this.history.pop();
            this.redoStack.push(lastAction);
            return true;
        }
        return false;
    }

    redo() {
        if (this.redoStack.length > 0) {
            const lastRedoAction = this.redoStack.pop();
            this.history.push(lastRedoAction);
            return true;
        }
        return false;
    }

    clearHistory() {
        this.history = [];
        this.redoStack = [];
    }

    saveToFile() {
        try {
            fs.writeFileSync(this.filePath, JSON.stringify(this.history, null, 2));
            console.log('Drawing history saved to file.');
            return true;
        } catch (error) {
            console.error('Error saving drawing history to file:', error);
            return false;
        }
    }

    loadFromFile() {
        try {
            if (fs.existsSync(this.filePath)) {
                const data = fs.readFileSync(this.filePath, 'utf8');
                this.history = JSON.parse(data);
                this.redoStack = []; // Clear redo stack on load
                console.log('Drawing history loaded from file.');
                return true;
            }
            console.log('No saved drawing history found.');
            return false;
        } catch (error) {
            console.error('Error loading drawing history from file:', error);
            return false;
        }
    }
}

module.exports = DrawingState;
