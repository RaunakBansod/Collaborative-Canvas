const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const drawingState = require('./drawing-state');
const roomManager = require('./rooms');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const PORT = process.env.PORT || 3000;

// Enable CORS for Vercel deployment
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

// Serve static files from the 'client' directory
app.use(express.static(path.join(__dirname, '../client')));

io.on('connection', (socket) => {
    console.log('A user connected');

    let currentRoomId = null;
    let userId = null;

    socket.on('joinRoom', (roomId) => {
        if (currentRoomId) {
            // Leave previous room if any
            roomManager.leaveRoom(currentRoomId, userId);
            socket.leave(currentRoomId);
            io.to(currentRoomId).emit('userLeft', userId);
            io.to(currentRoomId).emit('userList', roomManager.getUsersInRoom(currentRoomId));
        }

        currentRoomId = roomId;
        userId = socket.id; // Using socket ID as user ID for simplicity
        // Ensure room exists and create/join user (assign color)
        roomManager.createRoom(currentRoomId);
        const user = roomManager.joinRoom(currentRoomId, userId, socket.id);

        socket.join(currentRoomId);

        // Notify the room about the join and send updated user list (including colors)
        io.to(currentRoomId).emit('userJoined', user);
        io.to(currentRoomId).emit('userList', roomManager.getUsersInRoom(currentRoomId));

        // Send the current drawing history to the newly connected client for this room
        const ds = roomManager.getDrawingState(currentRoomId);
        if (ds) {
            socket.emit('drawingHistory', ds.getDrawingHistory());
        } else {
            socket.emit('drawingHistory', []);
        }
    });

    // Rate limiting for draw events
    const rateLimiter = {
        lastDrawTime: new Map(),
        minInterval: 16, // ms between draw events (roughly 60fps)
        checkLimit(userId) {
            const now = Date.now();
            const last = this.lastDrawTime.get(userId) || 0;
            if (now - last < this.minInterval) return false;
            this.lastDrawTime.set(userId, now);
            return true;
        }
    };

    // Handle live drawing events ('draw' with types 'start'|'draw'|'stop')
    socket.on('draw', (data) => {
        if (!currentRoomId || !data || !data.type || !data.stroke) {
            socket.emit('error', { message: 'Invalid draw event' });
            return;
        }

        // Rate limiting
        if (data.type === 'draw' && !rateLimiter.checkLimit(userId)) {
            return; // Silently drop too-frequent updates
        }

        const ds = roomManager.getDrawingState(currentRoomId);
        if (!ds) {
            socket.emit('error', { message: 'Drawing state not found' });
            return;
        }

        // For 'stop' events, persist the stroke and assign an operation ID
        if (data.type === 'stop') {
            const op = {
                type: 'stroke',
                userId: userId,
                color: data.stroke.color,
                width: data.stroke.width,
                tool: data.stroke.tool,
                points: data.stroke.points
            };

            const opId = ds.addDrawingAction(op);
            if (opId === null) {
                socket.emit('error', { message: 'Invalid stroke data' });
                return;
            }

            // Include opId in broadcast for client acknowledgment
            const user = roomManager.getUsersInRoom(currentRoomId).find(u => u.id === userId) || {};
            socket.broadcast.to(currentRoomId).emit('draw', {
                ...data,
                userId,
                color: user.color,
                opId
            });

            // Acknowledge receipt to sender
            socket.emit('drawAck', { opId });
        } else {
            // For 'start' and 'draw' events, just broadcast with user info
            const user = roomManager.getUsersInRoom(currentRoomId).find(u => u.id === userId) || {};
            socket.broadcast.to(currentRoomId).emit('draw', {
                ...data,
                userId,
                color: user.color
            });
        }
    });

    socket.on('cursorMove', (data) => {
        if (!currentRoomId) return; // Ensure user is in a room
        const user = roomManager.getUsersInRoom(currentRoomId).find(u => u.id === userId) || {};
        socket.broadcast.to(currentRoomId).emit('cursorMove', { userId: userId, x: data.x, y: data.y, color: user.color });
    });

    socket.on('undo', (roomId) => {
        if (!roomId || !roomManager.getDrawingState(roomId)) return;
        if (roomManager.getDrawingState(roomId).undo()) {
            io.to(roomId).emit('drawingHistory', roomManager.getDrawingState(roomId).getDrawingHistory());
        }
    });

    socket.on('redo', (roomId) => {
        if (!roomId || !roomManager.getDrawingState(roomId)) return;
        if (roomManager.getDrawingState(roomId).redo()) {
            io.to(roomId).emit('drawingHistory', roomManager.getDrawingState(roomId).getDrawingHistory());
        }
    });

    socket.on('saveDrawing', (roomId) => {
        if (!roomId || !roomManager.getDrawingState(roomId)) return;
        roomManager.getDrawingState(roomId).saveToFile();
    });

    socket.on('loadDrawing', (roomId) => {
        if (!roomId || !roomManager.getDrawingState(roomId)) return;
        roomManager.getDrawingState(roomId).loadFromFile();
        io.to(roomId).emit('drawingHistory', roomManager.getDrawingState(roomId).getDrawingHistory());
    });

    // Client can request current in-memory history (no file I/O)
    socket.on('requestHistory', (roomId) => {
        if (!roomId || !roomManager.getDrawingState(roomId)) {
            socket.emit('drawingHistory', []);
            return;
        }
        socket.emit('drawingHistory', roomManager.getDrawingState(roomId).getDrawingHistory());
    });

    socket.on('ping', (startTime) => {
        socket.emit('pong', startTime);
    });

    socket.on('disconnect', () => {
        console.log('User disconnected');
        if (currentRoomId && userId) {
            roomManager.leaveRoom(currentRoomId, userId);
            io.to(currentRoomId).emit('userLeft', userId);
            io.to(currentRoomId).emit('userList', roomManager.getUsersInRoom(currentRoomId));
        }
    });
});

server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
