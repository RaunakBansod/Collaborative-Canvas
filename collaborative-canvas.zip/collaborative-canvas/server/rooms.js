
const { v4: uuidv4 } = require('uuid');
const DrawingState = require('./drawing-state');

class RoomManager {
    constructor() {
        // rooms: { [roomId]: { users: { [userId]: { id, socketId } }, drawingState: DrawingState } }
        this.rooms = {};
    }

    // Ensure a room exists. If roomId is falsy, generate one.
    createRoom(roomId) {
        if (!roomId) {
            roomId = uuidv4();
        }

        if (!this.rooms[roomId]) {
            const drawingState = new DrawingState(roomId);
            // Try to load any saved history for this room (no-op if none)
            drawingState.loadFromFile();
            this.rooms[roomId] = {
                users: {},
                drawingState
            };
        }

        return this.rooms[roomId];
    }

    // Add a user to a room. Returns the user object.
    joinRoom(roomId, userId, socketId) {
        const room = this.createRoom(roomId);

        // If user already exists (reconnect), keep their color
        if (room.users[userId]) {
            room.users[userId].socketId = socketId;
            return room.users[userId];
        }

        // Assign a pleasant random color using HSL
        const hue = Math.floor(Math.random() * 360);
        const color = `hsl(${hue} 70% 50%)`;

        const user = { id: userId, socketId, color };
        room.users[userId] = user;
        return user;
    }

    // Remove a user from a room. Returns true if removed.
    leaveRoom(roomId, userId) {
        const room = this.rooms[roomId];
        if (!room || !room.users[userId]) return false;
        delete room.users[userId];

        // Optionally keep rooms even if empty so drawingState stays available.
        return true;
    }

    // Return an array of user objects in the room.
    getUsersInRoom(roomId) {
        const room = this.rooms[roomId];
        if (!room) return [];
        return Object.values(room.users);
    }

    getDrawingState(roomId) {
        const room = this.rooms[roomId];
        return room ? room.drawingState : null;
    }
}

module.exports = new RoomManager();

