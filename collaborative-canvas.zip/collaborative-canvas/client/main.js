import { socket, setUserListCallback, setCurrentRoomId } from './websocket.js';
import { Canvas } from './canvas.js';

document.addEventListener('DOMContentLoaded', () => {
    const canvasElement = document.getElementById('drawingCanvas');
    const cursorCanvasElement = document.getElementById('cursorCanvas');
    const canvas = new Canvas(canvasElement, socket, cursorCanvasElement);
    const userListElement = document.getElementById('userList');
    const fpsDisplay = document.getElementById('fpsDisplay');
    const latencyDisplay = document.getElementById('latencyDisplay');

    const brushToolButton = document.getElementById('brushTool');
    const eraserToolButton = document.getElementById('eraserTool');
    const colorPicker = document.getElementById('colorPicker');
    const strokeWidthSlider = document.getElementById('strokeWidth');
    const undoButton = document.getElementById('undoButton');
    const redoButton = document.getElementById('redoButton');
    const saveButton = document.getElementById('saveButton');
    const loadButton = document.getElementById('loadButton');
    const circleBrushButton = document.getElementById('circleBrush');
    const squareBrushButton = document.getElementById('squareBrush');

    const roomIdInput = document.getElementById('roomIdInput');
    const joinRoomButton = document.getElementById('joinRoomButton');
    const createRoomButton = document.getElementById('createRoomButton');

    let currentRoomId = 'defaultRoom'; // Default room

    // Brush type selection
    circleBrushButton.addEventListener('click', () => {
        canvas.setBrushType('circle');
        circleBrushButton.classList.add('active');
        squareBrushButton.classList.remove('active');
    });

    squareBrushButton.addEventListener('click', () => {
        canvas.setBrushType('square');
        squareBrushButton.classList.add('active');
        circleBrushButton.classList.remove('active');
    });

    const joinRoom = (roomId) => {
        if (roomId) {
            currentRoomId = roomId;
            setCurrentRoomId(roomId); // Set current room ID in websocket.js
            socket.emit('joinRoom', roomId);
            canvas.setRoomId(roomId);
            console.log(`Joined room: ${roomId}`);
            // Hide room selection UI and show drawing UI
            document.getElementById('room-selection').style.display = 'none';
            document.getElementById('toolbar').style.display = 'flex';
            document.getElementById('userList').style.display = 'block';
        } else {
            alert('Please enter a Room ID.');
        }
    };

    joinRoomButton.addEventListener('click', () => {
        joinRoom(roomIdInput.value);
    });

    createRoomButton.addEventListener('click', () => {
        const newRoomId = `room-${Math.random().toString(36).substring(7)}`;
        roomIdInput.value = newRoomId;
        joinRoom(newRoomId);
    });

    // Initially hide drawing UI until a room is joined
    document.getElementById('toolbar').style.display = 'none';
    document.getElementById('userList').style.display = 'none';

    brushToolButton.addEventListener('click', () => {
        canvas.setTool('brush');
        brushToolButton.classList.add('active');
        eraserToolButton.classList.remove('active');
    });

    eraserToolButton.addEventListener('click', () => {
        canvas.setTool('eraser');
        eraserToolButton.classList.add('active');
        brushToolButton.classList.remove('active');
    });

    colorPicker.addEventListener('input', (e) => {
        canvas.setColor(e.target.value);
    });

    strokeWidthSlider.addEventListener('input', (e) => {
        canvas.setStrokeWidth(parseInt(e.target.value));
    });

    undoButton.addEventListener('click', () => {
        socket.emit('undo', currentRoomId);
    });

    redoButton.addEventListener('click', () => {
        socket.emit('redo', currentRoomId);
    });

    saveButton.addEventListener('click', () => {
        socket.emit('saveDrawing', currentRoomId);
        alert('Drawing saved!');
    });

    loadButton.addEventListener('click', () => {
        socket.emit('loadDrawing', currentRoomId);
        alert('Drawing loaded!');
    });

    // Set initial active states
    brushToolButton.classList.add('active');
    circleBrushButton.classList.add('active');

    setUserListCallback((users) => {
        userListElement.innerHTML = '';
        users.forEach(user => {
            const userDiv = document.createElement('div');
            userDiv.style.color = user.color;
            userDiv.textContent = `User: ${user.id} (${user.color})`;
            userListElement.appendChild(userDiv);
        });
    });

    let lastCursorEmitTime = 0;
    const cursorThrottleDelay = 50; // milliseconds

    canvasElement.addEventListener('mousemove', (e) => {
        const currentTime = Date.now();
        if (currentTime - lastCursorEmitTime > cursorThrottleDelay) {
            socket.emit('cursorMove', { x: e.clientX, y: e.clientY, roomId: currentRoomId });
            lastCursorEmitTime = currentTime;
        }
    });

    // Performance Metrics
    let frameTimes = [];
    let lastFrameTime = performance.now();

    const calculateFps = () => {
        const now = performance.now();
        while (frameTimes.length > 0 && frameTimes[0] <= now - 1000) {
            frameTimes.shift();
        }
        frameTimes.push(now);
        fpsDisplay.textContent = frameTimes.length;
        requestAnimationFrame(calculateFps);
    };

    requestAnimationFrame(calculateFps);

    socket.on('pong', (startTime) => {
        const latency = performance.now() - startTime;
        latencyDisplay.textContent = Math.round(latency);
    });

    setInterval(() => {
        socket.emit('ping', performance.now());
    }, 1000);
});
