export class Canvas {
    constructor(canvasElement, socket, cursorCanvasElement) {
        this.canvas = canvasElement;
        this.ctx = canvasElement.getContext('2d');
        this.cursorCanvas = cursorCanvasElement;
        this.cursorCtx = cursorCanvasElement.getContext('2d');
        this.socket = socket;
        this.isDrawing = false;
        this.currentColor = '#000000';
        this.strokeWidth = 5;
        this.tool = 'brush';
        this.currentStroke = null; // To store points for the current stroke
        this.remoteCursors = {}; // Store remote cursor positions and colors
        this.roomId = null;
        this.brushes = {
            circle: this.circleBrush.bind(this),
            square: this.squareBrush.bind(this)
        };
        this.currentBrush = 'circle';

        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
        this.cursorCanvas.width = window.innerWidth;
        this.cursorCanvas.height = window.innerHeight;

        this.lastEmitTime = 0;
        this.throttleDelay = 16; // ~60fps

        this.setupContext();
        this.addEventListeners();

        // Offscreen canvases for per-user drawing
        this.offscreenCanvases = new Map(); // Map<userId, { canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D }>

        // Redraw on resize by requesting history from server
        window.addEventListener('resize', () => {
            const imgW = window.innerWidth;
            const imgH = window.innerHeight;
            this.canvas.width = imgW;
            this.canvas.height = imgH;
            this.cursorCanvas.width = imgW;
            this.cursorCanvas.height = imgH;

            // Resize all offscreen canvases
            this.offscreenCanvases.forEach(layer => {
                layer.canvas.width = imgW;
                layer.canvas.height = imgH;
            });

            if (this.roomId) this.socket.emit('requestHistory', this.roomId);
        });
    }

    setRoomId(roomId) {
        this.roomId = roomId;
    }

    setupContext(ctx = this.ctx) {
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.strokeStyle = this.currentColor;
        ctx.lineWidth = this.strokeWidth;
    }

    // Coordinate normalization
    normalizePoint(x, y) {
        return {
            x: x / this.canvas.width,
            y: y / this.canvas.height
        };
    }

    denormalizePoint(nx, ny) {
        return {
            x: nx * this.canvas.width,
            y: ny * this.canvas.height
        };
    }

    // Brush types
    circleBrush(ctx, x, y) {
        ctx.beginPath();
        ctx.arc(x, y, this.strokeWidth / 2, 0, Math.PI * 2);
        ctx.fill();
    }

    squareBrush(ctx, x, y) {
        const size = this.strokeWidth;
        ctx.fillRect(x - size/2, y - size/2, size, size);
    }

    setBrushType(type) {
        if (this.brushes[type]) {
            this.currentBrush = type;
        }
    }

    getOffscreenCanvas(userId) {
        if (!this.offscreenCanvases.has(userId)) {
            const offscreenCanvas = document.createElement('canvas');
            offscreenCanvas.width = this.canvas.width;
            offscreenCanvas.height = this.canvas.height;
            const offscreenCtx = offscreenCanvas.getContext('2d');
            this.setupContext(offscreenCtx);
            this.offscreenCanvases.set(userId, { canvas: offscreenCanvas, ctx: offscreenCtx });
        }
        return this.offscreenCanvases.get(userId);
    }

    clearOffscreenCanvas(userId) {
        const layer = this.offscreenCanvases.get(userId);
        if (layer) {
            layer.ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height);
        }
    }

    setTool(tool) {
        this.tool = tool;
        this.setupContext();
    }

    setColor(color) {
        this.currentColor = color;
        this.setupContext();
    }

    setStrokeWidth(width) {
        this.strokeWidth = width;
        this.setupContext();
    }

    addEventListeners() {
        this.canvas.addEventListener('mousedown', this.startDrawing.bind(this));
        this.canvas.addEventListener('mousemove', this.draw.bind(this));
        this.canvas.addEventListener('mouseup', this.stopDrawing.bind(this));
        this.canvas.addEventListener('mouseout', this.stopDrawing.bind(this));

        // Touch events
        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            this.startDrawing({ clientX: touch.clientX, clientY: touch.clientY });
        }, { passive: false });
        this.canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            const touch = e.touches[0];
            this.draw({ clientX: touch.clientX, clientY: touch.clientY });
        }, { passive: false });
        this.canvas.addEventListener('touchend', this.stopDrawing.bind(this));
        this.canvas.addEventListener('touchcancel', this.stopDrawing.bind(this));

        // Socket events
        this.socket.on('draw', (data) => this.handleRemoteDraw(data));
        this.socket.on('drawingHistory', (history) => this.loadDrawingHistory(history));
        this.socket.on('cursorMove', (data) => this.handleRemoteCursorMove(data));
        this.socket.on('userList', (users) => this.updateRemoteCursors(users));
        this.socket.on('userLeft', (userId) => this.removeRemoteCursor(userId));
    }

    loadDrawingHistory(history) {
        // Clear and replay entire history (operations)
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        // Clear all offscreen canvases
        this.offscreenCanvases.forEach(layer => layer.ctx.clearRect(0, 0, layer.canvas.width, layer.canvas.height));

        history.forEach(op => {
            if (op.type === 'stroke') {
                this.renderStroke(op, this.ctx); // Render historical strokes directly to main canvas
            }
        });
    }

    renderStroke(op, targetCtx) {
        if (!op.points || op.points.length === 0) return;
        const ctx = targetCtx || this.ctx;

        if (op.tool === 'eraser') {
            ctx.globalCompositeOperation = 'destination-out';
            ctx.strokeStyle = 'rgba(0,0,0,1)';
        } else {
            ctx.globalCompositeOperation = 'source-over';
            ctx.strokeStyle = op.color || '#000';
        }
        ctx.lineWidth = op.width || 1;

        ctx.beginPath();
        const pts = op.points;
        ctx.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i < pts.length - 1; i++) {
            const midX = (pts[i].x + pts[i + 1].x) / 2;
            const midY = (pts[i].y + pts[i + 1].y) / 2;
            ctx.quadraticCurveTo(pts[i].x, pts[i].y, midX, midY);
        }
        // finish
        if (pts.length > 1) {
            const last = pts[pts.length - 1];
            ctx.lineTo(last.x, last.y);
        }
        ctx.stroke();
    }

    handleRemoteDraw(data) {
        // data: { type, stroke, userId, color }
        if (!data || !data.stroke || !data.userId) return;
        const { type, stroke, userId, color } = data;

        const { ctx: remoteCtx } = this.getOffscreenCanvas(userId);

        if (type === 'start') {
            this.clearOffscreenCanvas(userId);
            remoteCtx.beginPath();
            remoteCtx.moveTo(stroke.points[0].x, stroke.points[0].y);
        } else if (type === 'draw') {
            this.renderStroke(stroke, remoteCtx);
        } else if (type === 'stop') {
            this.renderStroke(stroke, remoteCtx);
            // Composite the remote user's completed stroke onto the main canvas
            this.ctx.drawImage(remoteCtx.canvas, 0, 0);
            this.clearOffscreenCanvas(userId);
        }
    }

    startDrawing(e) {
        this.isDrawing = true;
        
        // Handle pressure sensitivity
        const pressure = e.pressure !== undefined ? e.pressure : 1.0;
        
        // Normalize coordinates
        const norm = this.normalizePoint(e.clientX, e.clientY);
        
        this.currentStroke = {
            tool: this.tool,
            color: this.currentColor,
            width: this.strokeWidth,
            brushType: this.currentBrush,
            points: [{
                x: norm.x,
                y: norm.y,
                pressure: pressure
            }]
        };

        // Store normalized coordinates
        this.lastPoint = norm;

        // Clear local offscreen canvas and start drawing there
        const { ctx: localCtx } = this.getOffscreenCanvas(this.socket.id);
        this.clearOffscreenCanvas(this.socket.id);
        
        // Denormalize for initial point
        const renderPoint = this.denormalizePoint(norm.x, norm.y);
        localCtx.beginPath();
        localCtx.moveTo(renderPoint.x, renderPoint.y);

        // Emit start event with normalized coordinates
        if (this.roomId) {
            this.socket.emit('draw', {
                type: 'start',
                stroke: this.currentStroke,
                roomId: this.roomId
            });
        }
    }

    draw(e) {
        if (!this.isDrawing || !this.currentStroke) return;

        const currentTime = Date.now();
        const newPoint = { x: e.clientX, y: e.clientY };
        this.currentStroke.points.push(newPoint);

        // local render incremental using quadratic smoothing on offscreen canvas
        const { ctx: localCtx } = this.getOffscreenCanvas(this.socket.id);
        localCtx.lineWidth = this.strokeWidth;
        if (this.tool === 'eraser') {
            localCtx.globalCompositeOperation = 'destination-out';
            localCtx.strokeStyle = 'rgba(0,0,0,1)';
        } else {
            localCtx.globalCompositeOperation = 'source-over';
            localCtx.strokeStyle = this.currentColor;
        }

        // draw smoothed segment between lastPoint and newPoint using midpoints
        const prev = this.lastPoint;
        const midX = (prev.x + newPoint.x) / 2;
        const midY = (prev.y + newPoint.y) / 2;

        localCtx.beginPath();
        localCtx.moveTo(prev.x, prev.y);
        localCtx.quadraticCurveTo(prev.x, prev.y, midX, midY);
        localCtx.stroke();

        this.lastPoint = newPoint;

        if (currentTime - this.lastEmitTime < this.throttleDelay) {
            return;
        }

        this.lastEmitTime = currentTime;
        if (this.roomId) this.socket.emit('draw', { type: 'draw', stroke: this.currentStroke, roomId: this.roomId });
    }

    stopDrawing() {
        if (!this.isDrawing) return;
        this.isDrawing = false;
        if (this.currentStroke) {
            if (this.roomId) this.socket.emit('draw', { type: 'stop', stroke: this.currentStroke, roomId: this.roomId });
            // Composite the local user's completed stroke onto the main canvas
            const { ctx: localCtx, canvas: localCanvas } = this.getOffscreenCanvas(this.socket.id);
            this.ctx.drawImage(localCanvas, 0, 0);
            this.clearOffscreenCanvas(this.socket.id);
            this.currentStroke = null;
        }
    }

    handleRemoteCursorMove(data) {
        const { userId, x, y, color } = data;
        this.remoteCursors[userId] = { x, y, color: color || (this.remoteCursors[userId] ? this.remoteCursors[userId].color : '#000000') };
        this.drawRemoteCursors();
    }

    updateRemoteCursors(users) {
        users.forEach(user => {
            if (this.remoteCursors[user.id]) {
                this.remoteCursors[user.id].color = user.color;
            } else {
                this.remoteCursors[user.id] = { x: 0, y: 0, color: user.color };
                // Create offscreen canvas for new user
                this.getOffscreenCanvas(user.id);
            }
        });
        for (const userId in this.remoteCursors) {
            if (!users.some(user => user.id === userId)) {
                delete this.remoteCursors[userId];
                // Remove offscreen canvas for user who left
                this.offscreenCanvases.delete(userId);
            }
        }
        this.drawRemoteCursors();
    }

    removeRemoteCursor(userId) {
        delete this.remoteCursors[userId];
        this.offscreenCanvases.delete(userId);
        this.drawRemoteCursors();
    }

    drawRemoteCursors() {
        this.cursorCtx.clearRect(0, 0, this.cursorCanvas.width, this.cursorCanvas.height);
        for (const userId in this.remoteCursors) {
            const cursor = this.remoteCursors[userId];
            this.cursorCtx.save();
            this.cursorCtx.beginPath();
            this.cursorCtx.arc(cursor.x, cursor.y, 8, 0, Math.PI * 2, false);
            this.cursorCtx.fillStyle = cursor.color || '#000';
            this.cursorCtx.fill();
            this.cursorCtx.lineWidth = 2;
            this.cursorCtx.strokeStyle = '#000000';
            this.cursorCtx.stroke();
            this.cursorCtx.restore();
        }
    }
}
