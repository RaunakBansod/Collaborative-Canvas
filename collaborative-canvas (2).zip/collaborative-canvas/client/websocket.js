const getServerUrl = () => {
    if (window.location.hostname === 'localhost') {
        return 'http://localhost:3000';
    }
    return window.location.origin;
};

export const socket = io(getServerUrl(), {
    path: '/socket.io',
    transports: ['websocket', 'polling'],
    reconnectionAttempts: 5,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
    timeout: 20000,
    autoConnect: true,
    forceNew: true
});

socket.on('connect', () => {
    console.log('Connected to WebSocket server');
});

socket.on('disconnect', () => {
    console.log('Disconnected from WebSocket server. Attempting to reconnect...');
    // Implement reconnection logic here if needed
});

socket.on('reconnect', () => {
    console.log('Reconnected to WebSocket server.');
    // Re-join the room if applicable
    if (currentRoomId) {
        socket.emit('joinRoom', currentRoomId);
    }
});

let userListCallback = null;

export const setUserListCallback = (callback) => {
    userListCallback = callback;
};

socket.on('userList', (users) => {
    console.log('Current users:', users);
    if (userListCallback) {
        userListCallback(users);
    }
});

socket.on('userJoined', (user) => {
    console.log('User joined:', user);
    // Handle user joined event (e.g., display a notification)
});

socket.on('userLeft', (userId) => {
    console.log('User left:', userId);
    // Handle user left event (e.g., remove from user list)
});

let cursorMoveCallback = null;

export const setCursorMoveCallback = (callback) => {
    cursorMoveCallback = callback;
};

socket.on('cursorMove', (data) => {
    if (cursorMoveCallback) {
        cursorMoveCallback(data);
    }
});

let currentRoomId = 'defaultRoom'; // This will be set by main.js

export const setCurrentRoomId = (roomId) => {
    currentRoomId = roomId;
};
