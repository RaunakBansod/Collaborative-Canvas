const app = require('express')();
const server = require('http').Server(app);
const io = require('socket.io')(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"],
        credentials: true
    },
    path: '/socket.io'
});

const drawingState = require('./server/drawing-state');
const roomManager = require('./server/rooms');

// In-memory state for serverless environment
let rooms = new Map();

app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
});

io.on('connection', (socket) => {
    console.log('Client connected');
    
    let currentRoomId = null;
    let userId = null;

    socket.on('joinRoom', (roomId) => {
        try {
            if (currentRoomId) {
                roomManager.leaveRoom(currentRoomId, userId);
                socket.leave(currentRoomId);
                io.to(currentRoomId).emit('userLeft', userId);
                io.to(currentRoomId).emit('userList', roomManager.getUsersInRoom(currentRoomId));
            }

            currentRoomId = roomId;
            userId = socket.id;
            roomManager.createRoom(currentRoomId);
            const user = roomManager.joinRoom(currentRoomId, userId, socket.id);

            socket.join(currentRoomId);
            io.to(currentRoomId).emit('userJoined', user);
            io.to(currentRoomId).emit('userList', roomManager.getUsersInRoom(currentRoomId));

            const ds = roomManager.getDrawingState(currentRoomId);
            if (ds) {
                socket.emit('drawingHistory', ds.getDrawingHistory());
            } else {
                socket.emit('drawingHistory', []);
            }
        } catch (error) {
            console.error('Error in joinRoom:', error);
            socket.emit('error', { message: 'Failed to join room' });
        }
    });

    socket.on('draw', (data) => {
        try {
            if (!currentRoomId || !data || !data.type || !data.stroke) {
                socket.emit('error', { message: 'Invalid draw event' });
                return;
            }

            const ds = roomManager.getDrawingState(currentRoomId);
            if (!ds) {
                socket.emit('error', { message: 'Drawing state not found' });
                return;
            }

            const user = roomManager.getUsersInRoom(currentRoomId).find(u => u.id === userId) || {};
            
            if (data.type === 'stop') {
                const op = {
                    type: 'stroke',
                    userId: userId,
                    color: data.stroke.color,
                    width: data.stroke.width,
                    tool: data.stroke.tool,
                    points: data.stroke.points
                };

                const opId = ds.addDrawingAction(op);
                socket.broadcast.to(currentRoomId).emit('draw', {
                    ...data,
                    userId,
                    color: user.color,
                    opId
                });
                socket.emit('drawAck', { opId });
            } else {
                socket.broadcast.to(currentRoomId).emit('draw', {
                    ...data,
                    userId,
                    color: user.color
                });
            }
        } catch (error) {
            console.error('Error in draw:', error);
            socket.emit('error', { message: 'Failed to process draw event' });
        }
    });

    socket.on('disconnect', () => {
        try {
            console.log('Client disconnected');
            if (currentRoomId && userId) {
                roomManager.leaveRoom(currentRoomId, userId);
                io.to(currentRoomId).emit('userLeft', userId);
                io.to(currentRoomId).emit('userList', roomManager.getUsersInRoom(currentRoomId));
            }
        } catch (error) {
            console.error('Error in disconnect:', error);
        }
    });
});

module.exports = app;