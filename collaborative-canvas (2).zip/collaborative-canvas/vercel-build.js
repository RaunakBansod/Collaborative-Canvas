const fs = require('fs');
const path = require('path');

// Ensure the api directory exists
if (!fs.existsSync('api')) {
    fs.mkdirSync('api');
}

// Copy necessary files to api directory
fs.copyFileSync(
    path.join(__dirname, 'server', 'drawing-state.js'),
    path.join(__dirname, 'api', 'drawing-state.js')
);

fs.copyFileSync(
    path.join(__dirname, 'server', 'rooms.js'),
    path.join(__dirname, 'api', 'rooms.js')
);