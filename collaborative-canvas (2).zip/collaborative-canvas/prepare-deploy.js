const fs = require('fs');
const path = require('path');

// Ensure client directory exists
const clientDir = path.join(__dirname, 'client');
if (!fs.existsSync(clientDir)) {
    fs.mkdirSync(clientDir, { recursive: true });
}

// Copy client files if they're not in the right place
// No need to copy client files, they are already in the client/ directory

// Create api directory if it doesn't exist
const apiDir = path.join(__dirname, 'api');
if (!fs.existsSync(apiDir)) {
    fs.mkdirSync(apiDir, { recursive: true });
}

// Copy server files to api/server directory
const serverFiles = {
    'server/drawing-state.js': 'api/server/drawing-state.js',
    'server/rooms.js': 'api/server/rooms.js'
};

for (const [src, dest] of Object.entries(serverFiles)) {
    const sourcePath = path.join(__dirname, src);
    const destPath = path.join(__dirname, dest);
    if (fs.existsSync(sourcePath)) {
        fs.copyFileSync(sourcePath, destPath);
    }
}

console.log('Files prepared for deployment');