# Architecture Overview

This document outlines the architecture of the collaborative drawing canvas application, covering data flow, WebSocket protocol, undo/redo system, performance considerations, and conflict resolution.

## Data Flow Diagram

```text
+----------------+
|    Frontend    |
| (client/ SPA)  |
+-------+--------+
        | (WebSocket)
        | Drawing Events (start, draw, stop)
        | Cursor Move Events
        | Undo/Redo Requests
        v
+-------+--------+
|     Backend    |
| (Node.js/Express)|
| (Socket.io)    |
+-------+--------+
        | (Internal Modules)
        | Room Management (rooms.js)
        | Drawing State (drawing-state.js)
        v
+-------+--------+
|  Shared State  |
| (In-memory)    |
+----------------+
```

### Explanation:

*   **Frontend (Client):** A single-page application (SPA) built with Vanilla JavaScript, HTML5 Canvas, and CSS. It handles user input, local drawing, and rendering of remote drawing data and cursors.
*   **WebSocket Connection:** The primary communication channel between the frontend and backend, established using Socket.io.
*   **Backend (Node.js/Express/Socket.io):** A Node.js server that uses Express to serve static client files and Socket.io for real-time bidirectional communication. It manages rooms, user sessions, and the shared drawing state.
*   **Internal Modules:**
    *   `rooms.js`: Manages rooms and connected users within each room, assigning unique IDs and colors.
    *   `drawing-state.js`: Maintains the history of drawing actions for each room, supporting undo/redo operations.
*   **Shared State (In-memory):** The drawing history and user information are stored in memory on the server. For production, this would typically be backed by a persistent database.

## WebSocket Message Protocol

All WebSocket communication uses Socket.io events.

### Client to Server Events:

*   `drawing`: Sent by the client to broadcast drawing actions.
    *   `data`: `{ type: 'start' | 'draw' | 'stop', stroke: { userId: string, tool: string, color: string, width: number, points: [{x: number, y: number}, ...] } }`
        *   `type`: Indicates the phase of the drawing stroke (`start`, `draw`, `stop`).
        *   `stroke`: An object containing details of the drawing stroke.
            *   `userId`: The ID of the user performing the drawing.
            *   `tool`: The drawing tool used (e.g., 'brush', 'eraser').
            *   `color`: The color of the stroke (hex code).
            *   `width`: The stroke width.
            *   `points`: An array of `{x, y}` coordinates representing the path of the stroke.
*   `cursorMove`: Sent by the client to broadcast its current cursor position.
    *   `data`: `{ x: number, y: number }`
        *   `x`, `y`: The x and y coordinates of the cursor.
*   `undo`: Sent by the client to request an undo operation.
    *   `data`: (None)
*   `redo`: Sent by the client to request a redo operation.
    *   `data`: (None)

### Server to Client Events:

*   `drawing`: Broadcast to all clients in a room when a user performs a drawing action.
    *   `data`: `{ type: 'start' | 'draw' | 'stop', stroke: { userId: string, tool: string, color: string, width: number, points: [{x: number, y: number}, ...] } }` (Same as client-to-server `drawing` event, with `userId` added by server).
*   `cursorMove`: Broadcast to all clients in a room (except the sender) when a user moves their cursor.
    *   `data`: `{ userId: string, x: number, y: number }`
        *   `userId`: The ID of the user whose cursor moved.
        *   `x`, `y`: The x and y coordinates of the cursor.
*   `userJoined`: Broadcast to all clients in a room when a new user connects.
    *   `data`: `{ id: string, color: string, socketId: string }`
        *   `id`: The ID of the joined user.
        *   `color`: The assigned color of the joined user.
        *   `socketId`: The Socket.io ID of the joined user.
*   `userLeft`: Broadcast to all clients in a room when a user disconnects.
    *   `data`: `string` (The ID of the user who left).
*   `userList`: Sent to a newly connected client (and broadcast on user join/leave) with the current list of users in the room.
    *   `data`: `[{ id: string, color: string, socketId: string }, ...]` (An array of user objects).
*   `drawingHistory`: Sent to a newly connected client (and after undo/redo) with the complete drawing history of the room.
    *   `data`: `[{ userId: string, tool: string, color: string, width: number, points: [{x: number, y: number}, ...], timestamp: number }, ...]` (An array of completed stroke objects).

## Undo/Redo Architecture

The undo/redo system is implemented globally across all users and is managed on the backend:

1.  **Operation Stack:** The `DrawingState` class in `server/drawing-state.js` maintains two arrays: `history` and `redoStack`.
    *   `history`: Stores all completed drawing strokes (type `stop`) as individual operations, along with a `timestamp` and `userId`.
    *   `redoStack`: Temporarily stores operations that have been undone.
2.  **Adding Operations:** When a client completes a drawing stroke (`type: 'stop'`), the backend adds the stroke object to the `history` array and clears the `redoStack`.
3.  **Undo Operation:** When a client emits an `undo` event, the backend pops the last operation from `history` and pushes it onto `redoStack`. The updated `drawingHistory` is then broadcast to all clients.
4.  **Redo Operation:** When a client emits a `redo` event, the backend pops the last operation from `redoStack` and pushes it back onto `history`. The updated `drawingHistory` is then broadcast to all clients.
5.  **Frontend Re-rendering:** Upon receiving a `drawingHistory` event, the frontend (`client/canvas.js`) clears its canvas and re-renders all strokes from the received history, ensuring a synchronized view for all users.

## Performance Optimization Decisions

### 1. Event Throttling
- Drawing events throttled to 16ms (~60fps) for optimal performance
- Cursor movement events throttled to 50ms to reduce network traffic
- Rate limiting implemented on server-side to prevent flooding

### 2. Canvas Optimization
- Offscreen canvas layers for per-user drawing
- Separate cursor canvas for smoother updates
- Coordinate normalization for consistent rendering
- Efficient stroke rendering using quadratic curves
- Canvas size adaptation on window resize

### 3. Data Optimization
- Minimal stroke object serialization
- Point data compression for network transfer
- Efficient brush rendering algorithms
- Optimized color and tool state management
- Smart update batching for multi-user sync

### 4. Client-Side Performance
- Local preview for immediate feedback
- FPS monitoring and display
- Latency tracking and reporting
- Efficient DOM updates for UI
- Browser-specific optimizations

### 5. Server-Side Optimization
- Memory-efficient stroke storage
- Quick room state lookups
- Efficient user management
- Optimized broadcast mechanisms
- Smart conflict resolution

## Conflict Resolution Approach

*   **Server-Side Ordering:** All drawing actions are processed and stored on the server. Each completed stroke is timestamped and associated with a `userId` in `server/drawing-state.js`. This establishes a definitive order of operations.
*   **Global Undo/Redo:** The undo/redo system operates on a single, shared history stack on the server. This means an undo/redo action by any user affects the global canvas state, simplifying conflict resolution for these operations.
*   **`globalCompositeOperation` for Tools:** The `Canvas` class uses `ctx.globalCompositeOperation` (`source-over` for brush, `destination-out` for eraser) to correctly blend drawing actions. This inherently handles basic overlapping drawing conflicts for different tools.
*   **Full Canvas Re-render on Sync:** When a new client connects or an undo/redo operation occurs, the entire canvas is re-rendered from the server's authoritative drawing history. This ensures all clients have a consistent view of the canvas state.
*   **Deferred Per-User Layers:** A more advanced conflict resolution strategy involving per-user layers (where each user draws on a separate offscreen canvas, and these layers are composited) has been considered but deferred for future implementation. This would provide finer-grained control over overlapping strokes and reduce potential visual artifacts during concurrent drawing.
